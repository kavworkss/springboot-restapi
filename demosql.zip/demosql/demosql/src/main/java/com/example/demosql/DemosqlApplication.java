package com.example.demosql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemosqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemosqlApplication.class, args);
	}

}
