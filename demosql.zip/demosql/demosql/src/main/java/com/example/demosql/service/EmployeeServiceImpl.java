package com.example.demosql.service;

import com.example.demosql.dao.EmployeeDAO;
import com.example.demosql.model.Employee;
import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service implementation for employee-related business logic.
 */
@Service
public class EmployeeServiceImpl implements EmployeeService {

    private final EmployeeDAO employeeDAO;

    // ✅ Constructor-based dependency injection
    public EmployeeServiceImpl(EmployeeDAO employeeDAO) {
        this.employeeDAO = employeeDAO;
    }

    @Transactional
    @Override
    public List<Employee> get() {
        return employeeDAO.get();
    }

    @Transactional
    @Override
    public Employee get(int id) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Transactional
    @Override
    public void save(Employee employee) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Transactional
    @Override
    public void delete(int id) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
